DSigner was originally programmed by Jonathan Scott for Friendcodes.com, you are welcome to use, modify and redistribute this application under the terms of the GNU General Public License (attached).

While I would recommend you read the attached document, essentially it means you can do what you like with this software (including charge for it!) as long as upon re-distribution:
	You offer the source code for download
	You leave the original copyright notices in-tact
	You include README.txt and License.txt


While it is not required, it would be helpful if you would submit any improvements to me (sunderlandafc@gmail.com) so I can include them in the official download for all to use.

This software is proved AS IS and I take no responsibilty for damages caused either by the software or by modifications made by other users to this software. I do NOT provide Java help, if you do not know Java I recommend the tutorials at Sun.com as a good place to start.

Credits

Jonathan Scott - Original Code, Export Templates
Jack Saghbazarian - Need4Speed Underground 2 Palette


ChangeLog

18/02/2007
	DSigner Lite source released by Jonathan Scott
